tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: '#10B981',
                secondary: '#059669',
                dark: '#064E3B',
                light: '#D1FAE5',
            }
        }
    }
}
